
public class DynamicArray {
    int numbers [] = new int[1];
    int size = 0;
    double  increaseFactor = 2;
    
    public void add(int number){
        if(size < numbers.length){
            numbers[size] = number;
            size++;
        }
        else{
            int newC = (int) Math.ceil(numbers.length*increaseFactor);
            int [] copy = new int[newC];
            for(int i = 0; i< numbers.length;i++)copy[i]=numbers[i];
            numbers=copy;
            numbers[size] = number;
            size = size + 1;  
        }
    }
}
