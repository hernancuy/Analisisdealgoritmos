
import java.time.Duration;
import java.time.Instant;


public class Main {

    public static void main(String[] args) { 
        
       testing(1.01, 100_000_000);
       testing(1.50, 100_000_000);
       testing(2.00, 100_000_000);
       
       /*testingExpanded(1.01, 100_000_000);
       testingExpanded(1.5, 100_000_000);
       testingExpanded(2.0, 100_000_000);*/
        
    }   
    
    
    public static void testing(double Factor, double elements ){
        DynamicArray array = new DynamicArray();
        array.increaseFactor = Factor;
        Instant start = Instant.now();
        System.out.println("Elements of array: "+elements);
        for (int i = 0; i < elements ; i++) {
            array.add(i);
            
        }
        Instant finish = Instant.now();
	long timeElapsed = Duration.between(start, finish).toMillis();
	System.out.println("increaseFactor: " + array.increaseFactor);
	System.out.println("Array Size: " + array.numbers.length);
	System.out.println("time Elapsed: " + timeElapsed + "ms");
	System.out.println();
        System.out.println();    
    }
        public static void testingExpanded(double Factor, double elements ){
        DynamicArray array = new DynamicArray();
        array.increaseFactor = Factor;
        System.out.println("Elements of array:");
        System.out.println("increaseFactor: " + array.increaseFactor);
        for (int i = 0; i < elements ; i++) {
            Instant start = Instant.now();
            array.add(i);
            Instant finish = Instant.now();
            long timeElapsed = Duration.between(start, finish).toMillis();	
            System.out.println("Array Size: " + array.numbers.length);
            System.out.println("time Elapsed: " + timeElapsed + "ms");
        }
	System.out.println();
        System.out.println();  
    }
}
